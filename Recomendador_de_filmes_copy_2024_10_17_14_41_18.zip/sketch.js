//Terror, suspense, drama, misterio

//Terrifier, +18, terror
//Panico na floresta, +14, terror, drama
//It a coisa, +16, terror, misterio
//Chucky, +16, terror, comedia
//Sexta-feira 13, +18, terror, crime
//A hora do pesadelo 2, +18, terror, fantasia



function setup() {
  createCanvas(400, 400);
}

function draw() { }
  background(220);
let idade = 15;
let recomendacao = geraRecomendacao(idade);
  text (recomendacao, width / 2, height / 2);
}

function geraRecomendacao(idade) 
 if(idade >=14)  
   return "Panico na floresta";

}
